<?php
require("include/header.php");
?>

<div id="wrapper">
<?php
require("include/menu.php"); 
?>

<div id="contentwrapper">


<div id="content">

<center>
<!--<img src="images/barrett-group-2009-06-web.jpg">-->
</center>

<h2>Accepted Papers</h2>
<p>
<ul>
    <li>
        <b>Modeling Crime diffusion and crime suppression on transportation networks: An initial report</b><br>
        Chao Zhang, Albert Xin Jiang, Martin Short, P. Jeffrey Brantingham and Milind Tambe<br>&nbsp;
    </li>
    <li>
        <b>Influence Study on Hyper-Graphs</b><br>
        Dimitrios Vogiatzis<br>&nbsp;
    </li>
    <li>
        <b>The Co-evolution of Communication Networks and Drinking Behaviors</b><br>
        Cheng Wang, David Hachen and Omar Lizardo<br>&nbsp;
    </li>
    <li>
        <b>A Study of Sourceforge Users and User Network</b><br>
        Liguo Yu and S. Ramaswamy<br>&nbsp;
    </li>
    <li>
        <b>Spatiotemporal Patterns in Social Networks</b><br>
        Nibir Bora, Vladimir Zaytsev, Yu-Han Chang and Rajiv Maheswaran<br>&nbsp;
    </li>
    <li>
        <b>Associative Patterns of Web-Browsing Behavior</b><br>
        Myriam Abramson and Shantanu Gore<br>&nbsp;
    </li>
    <li>
        <b>Mining for Spatially-Near Communities in Geo-Located Social Networks</b><br>
        Joseph Hannigan, Guillermo Hernandez, Richard M. Medina, Patrick Roos, and Paulo Shakarian<br>&nbsp;
    </li>
</ul>
</p>

<br><br>
<!--<a href="status.php" title="Project Status">Project Status</a>-->

</div> <!-- content -->
</div> <!-- contentwrapper -->
</div> <!-- wrapper -->

<?php
include("/include/footer.php");
?>
