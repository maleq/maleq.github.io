<?php
require("include/header.php");
?>

<div id="wrapper">
<?php
require("include/menu.php"); 
?>

<div id="contentwrapper">


<div id="content">

<p>
Part of the <a href="http://www.aaai.org/Symposia/Fall/fss13.php">AAAI Fall Symposium 2013 series</a>,
the Symposium on Social Networks and Social Contagion will be held on Nov 15-16, 2013, at the 
<a href="http://www.starwoodhotels.com/westin/property/overview/index.html?propertyID=1513">Westin Arlington Gateway</a>
in Arlington, VA.
</p>
<h2>Symposium theme:</h2>
<p>
With the emergence of Computational Social Science as a field of collaboration
between computer scientists and social scientists, the study of social networks
and processes on these networks (social contagion) has been gaining interest.
Many topics of traditional sociological interest (such as the diffusion of
innovation, emergence of norms, identification of influencer) can now be studied
using detailed computational models and extensive simulation. The advent and
popularity of online social media also allows the creation of massive data sets
which can inform models and underlying sociological theory. The ubiquity of
"smart devices" (such as smart phones) also provides opportunities to gather
extensive data on the behaviors and interactions of humans in "real space".
</p>
<p>
The goal of this symposium is to bring together a community of researchers
interested in addressing these issues and to encourage interdisciplinary
approaches to these problems.
</p>

<br><br>
<p>
    Contact: Samarth Swarup (swarup@vbi.vt.edu)
</p>
<!--<p>
    Funded in part by National Science Foundation NetSE Grant CNS-1011769. <img src="NSFlogoTrans.png" width="50" height="50" align="absmiddle">
</p>
-->
<br><br>
<!--<a href="status.php" title="Project Status">Project Status</a>-->

</div> <!-- content -->
</div> <!-- contentwrapper -->
</div> <!-- wrapper -->

<?php
include("/include/footer.php");
?>
