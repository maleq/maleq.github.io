<?php
require("include/header.php");
?>

<div id="wrapper">
<?php
require("include/menu.php"); 
?>

<div id="contentwrapper">


<div id="content">

<center>
<!--<img src="images/barrett-group-2009-06-web.jpg">-->
</center>

<p>
Online registration for AAAI 2013 Fall Symposium Series (FSS-13) can be done at
</p>
<p>
<a href="https://www.regonline.com/fss13">https://www.regonline.com/fss13</a>
</p>
<p>
The deadline for registration is <b>October 18</b>.
</p>
<p>
AAAI has reserved a block of rooms at the conference venue: the Westin Arlington Gateway Hotel.
To reserve a room online, please go to
<p>
<a href="https://www.starwoodmeeting.com/StarGroupsWeb/booking/reservation?id=1212274813&key=D45BE">https://www.starwoodmeeting.com/StarGroupsWeb/booking/reservation?id=1212274813&key=D45BE</a>
</p>
<p> 
Space is limited so we recommend that you make your reservation
now. Reservations made after <b>Thursday, October 24</b> will be accepted
based on availability at the hotel's prevailing rate.
</p>

</p>

<br><br>
<!--<a href="status.php" title="Project Status">Project Status</a>-->

</div> <!-- content -->
</div> <!-- contentwrapper -->
</div> <!-- wrapper -->

<?php
include("/include/footer.php");
?>
