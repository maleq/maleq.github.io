
<div id="footer"> 
<small><i>
&copy; 2004-2011 Network Dynamics and Simulation Science Laboratory<br>
1880 Pratt Drive, MC 0477; Virginia Tech, Blacksburg, VA 24061<br>
tel: (540) 231-8252; fax: (540) 231-2891
</i></small>

</div>

</body>
</html>


